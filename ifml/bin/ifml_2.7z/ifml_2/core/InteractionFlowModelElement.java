/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interaction Flow Model Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getInteractionFlowModelElement()
 * @model abstract="true"
 * @generated
 */
public interface InteractionFlowModelElement extends Element {
} // InteractionFlowModelElement
