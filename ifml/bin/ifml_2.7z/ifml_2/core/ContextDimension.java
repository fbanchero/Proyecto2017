/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Context Dimension</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getContextDimension()
 * @model
 * @generated
 */
public interface ContextDimension extends NamedElement {
} // ContextDimension
