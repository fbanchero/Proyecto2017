/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conditional Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getConditionalExpression()
 * @model
 * @generated
 */
public interface ConditionalExpression extends Expression, ViewComponentPart {
} // ConditionalExpression
