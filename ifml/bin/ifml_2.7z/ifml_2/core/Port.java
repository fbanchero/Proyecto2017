/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Port</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getPort()
 * @model
 * @generated
 */
public interface Port extends InteractionFlowElement {
} // Port
