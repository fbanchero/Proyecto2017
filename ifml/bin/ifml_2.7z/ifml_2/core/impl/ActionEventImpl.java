/**
 */
package ifml.core.impl;

import ifml.core.ActionEvent;
import ifml.core.CorePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Action Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ActionEventImpl extends EventImpl implements ActionEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActionEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.ACTION_EVENT;
	}

} //ActionEventImpl
