/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action Event</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getActionEvent()
 * @model
 * @generated
 */
public interface ActionEvent extends Event {
} // ActionEvent
