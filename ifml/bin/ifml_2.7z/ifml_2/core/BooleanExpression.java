/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Boolean Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getBooleanExpression()
 * @model
 * @generated
 */
public interface BooleanExpression extends Expression {
} // BooleanExpression
