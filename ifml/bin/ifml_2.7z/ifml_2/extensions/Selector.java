/**
 */
package ifml.extensions;

import ifml.core.Expression;
import ifml.core.ViewComponentPart;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Selector</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getSelector()
 * @model
 * @generated
 */
public interface Selector extends Expression, ViewComponentPart {
} // Selector
