/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ContextDimensionImpl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.UserRole;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>User Role</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class UserRoleImpl extends ContextDimensionImpl implements UserRole {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected UserRoleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.USER_ROLE;
	}

} //UserRoleImpl
