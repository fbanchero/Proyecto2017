/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ContextDimensionImpl;

import ifml.extensions.Device;
import ifml.extensions.ExtensionsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Device</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DeviceImpl extends ContextDimensionImpl implements Device {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DeviceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.DEVICE;
	}

} //DeviceImpl
