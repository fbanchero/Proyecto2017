/**
 */
package ifml.extensions;

import ifml.core.ViewComponent;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Details</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getDetails()
 * @model
 * @generated
 */
public interface Details extends ViewComponent {
} // Details
