/**
 */
package ifml.extensions;

import ifml.core.ViewElementEvent;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Select Event</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getSelectEvent()
 * @model
 * @generated
 */
public interface SelectEvent extends ViewElementEvent {
} // SelectEvent
