/**
 */
package ifml.extensions;

import ifml.core.ContextDimension;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>User Role</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getUserRole()
 * @model
 * @generated
 */
public interface UserRole extends ContextDimension {
} // UserRole
