/**
 */
package ifml.extensions;

import ifml.core.Constraint;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Validation Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getValidationRule()
 * @model
 * @generated
 */
public interface ValidationRule extends Constraint {
} // ValidationRule
