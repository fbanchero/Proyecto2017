/**
 */
package ifml.extensions;

import ifml.core.ViewElementEvent;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Submit Event</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getSubmitEvent()
 * @model
 * @generated
 */
public interface SubmitEvent extends ViewElementEvent {
} // SubmitEvent
