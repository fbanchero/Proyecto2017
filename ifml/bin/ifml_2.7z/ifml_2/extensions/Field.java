/**
 */
package ifml.extensions;

import ifml.core.ViewComponentPart;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Field</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getField()
 * @model abstract="true"
 * @generated
 */
public interface Field extends ViewComponentPart {
} // Field
