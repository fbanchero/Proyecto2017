/**
 */
package ifml.extensions;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Field</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getSimpleField()
 * @model
 * @generated
 */
public interface SimpleField extends Field {
} // SimpleField
