/**
 */
package ifml.extensions;

import ifml.core.ContextDimension;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Position</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.extensions.ExtensionsPackage#getPosition()
 * @model
 * @generated
 */
public interface Position extends ContextDimension {
} // Position
