/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Activation Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getActivationExpression()
 * @model
 * @generated
 */
public interface ActivationExpression extends BooleanExpression {
} // ActivationExpression
