/**
 */
package ifml.core.impl;

import ifml.core.CorePackage;
import ifml.core.ViewElementEvent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>View Element Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ViewElementEventImpl extends EventImpl implements ViewElementEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ViewElementEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.VIEW_ELEMENT_EVENT;
	}

} //ViewElementEventImpl
