/**
 */
package ifml.core.impl;

import ifml.core.ActivationExpression;
import ifml.core.CorePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Activation Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ActivationExpressionImpl extends BooleanExpressionImpl implements ActivationExpression {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActivationExpressionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.ACTIVATION_EXPRESSION;
	}

} //ActivationExpressionImpl
