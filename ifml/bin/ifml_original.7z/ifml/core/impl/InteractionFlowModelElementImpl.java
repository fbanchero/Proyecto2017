/**
 */
package ifml.core.impl;

import ifml.core.CorePackage;
import ifml.core.InteractionFlowModelElement;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interaction Flow Model Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class InteractionFlowModelElementImpl extends ElementImpl implements InteractionFlowModelElement {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InteractionFlowModelElementImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.INTERACTION_FLOW_MODEL_ELEMENT;
	}

} //InteractionFlowModelElementImpl
