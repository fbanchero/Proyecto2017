/**
 */
package ifml.core.impl;

import ifml.core.CorePackage;
import ifml.core.ExternalEvent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>External Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ExternalEventImpl extends EventImpl implements ExternalEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExternalEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.EXTERNAL_EVENT;
	}

} //ExternalEventImpl
