/**
 */
package ifml.core.impl;

import ifml.core.ContextDimension;
import ifml.core.CorePackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Context Dimension</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ContextDimensionImpl extends NamedElementImpl implements ContextDimension {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContextDimensionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CorePackage.Literals.CONTEXT_DIMENSION;
	}

} //ContextDimensionImpl
