/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constraint</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getConstraint()
 * @model
 * @generated
 */
public interface Constraint extends BooleanExpression {
} // Constraint
