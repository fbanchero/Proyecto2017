/**
 */
package ifml.core;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>External Event</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see ifml.core.CorePackage#getExternalEvent()
 * @model
 * @generated
 */
public interface ExternalEvent extends Event {
} // ExternalEvent
