/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ContextDimensionImpl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.Position;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Position</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PositionImpl extends ContextDimensionImpl implements Position {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PositionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.POSITION;
	}

} //PositionImpl
