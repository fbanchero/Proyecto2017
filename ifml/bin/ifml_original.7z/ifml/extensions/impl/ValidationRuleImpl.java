/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ConstraintImpl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.ValidationRule;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Validation Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ValidationRuleImpl extends ConstraintImpl implements ValidationRule {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ValidationRuleImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.VALIDATION_RULE;
	}

} //ValidationRuleImpl
