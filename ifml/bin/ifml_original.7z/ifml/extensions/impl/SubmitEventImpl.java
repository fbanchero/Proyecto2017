/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ViewElementEventImpl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.SubmitEvent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Submit Event</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SubmitEventImpl extends ViewElementEventImpl implements SubmitEvent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SubmitEventImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.SUBMIT_EVENT;
	}

} //SubmitEventImpl
