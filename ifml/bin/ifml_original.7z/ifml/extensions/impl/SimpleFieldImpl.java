/**
 */
package ifml.extensions.impl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.SimpleField;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Simple Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SimpleFieldImpl extends FieldImpl implements SimpleField {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SimpleFieldImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.SIMPLE_FIELD;
	}

} //SimpleFieldImpl
