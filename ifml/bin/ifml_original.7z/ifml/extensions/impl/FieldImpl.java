/**
 */
package ifml.extensions.impl;

import ifml.core.impl.ViewComponentPartImpl;

import ifml.extensions.ExtensionsPackage;
import ifml.extensions.Field;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Field</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class FieldImpl extends ViewComponentPartImpl implements Field {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FieldImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExtensionsPackage.Literals.FIELD;
	}

} //FieldImpl
